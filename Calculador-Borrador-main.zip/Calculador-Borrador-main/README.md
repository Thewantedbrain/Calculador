# Hello

## This is a Calculator

![Simulator Screen Shot - iPhone 13 - 2022-02-24 at 02 25 17](https://user-images.githubusercontent.com/43630417/155477881-5bd39925-55c3-4e22-9966-9ebc0976a863.png)
![Simulator Screen Shot - iPhone 13 - 2022-02-24 at 02 28 36](https://user-images.githubusercontent.com/43630417/155478260-05e30110-3144-4e99-8690-048bc8a00c8f.png)

### Features
- Dark mode
- Beautiful UI
- Minimalistic

### Tools
- React Native Expo
- Typescript

### Want to clone this project?
At the root folder run:
```
yarn && expo start
```
